"Recently Purchased" Social Proof Popup
=========================================
New:     app/api/social-proof/route.ts   (public, sources REAL anonymized purchases)
New:     components/SocialProofPopup.tsx (the toast/popup itself)
Updated: app/layout.tsx                  (renders the popup globally)

Deliberately uses REAL data, not fake/simulated activity - showing fake
purchases would be misleading. To keep it privacy-safe:
  - Only shows first name + last initial (e.g. "Chidi O."), never full
    name or email
  - Only sources 'account_purchase' and 'smm' transaction types -
    'virtual_number' purchases are excluded because their description
    contains the actual phone number, which must never be shown publicly
  - No purchase amounts shown
  - Only looks at the last 48 hours, so it goes quiet on its own if
    there's been no recent activity (never fabricates activity to fill
    the gap)
  - Hidden entirely on /admin pages and the login/register pages

Behavior: cycles through real recent purchases, showing one toast in the
bottom-left corner for 5 seconds every ~8-11 seconds, looping. If there
are no qualifying purchases in the last 48h, nothing renders at all.

HOW TO USE:
1. Upload to repo root in Codespace.
2. unzip -o social-proof-popup.zip -d .
   rm social-proof-popup.zip
3. npm run dev - buy a test item (account/log or SMM order) to generate
   a qualifying transaction, then check the storefront for the popup.
4. git add app/api/social-proof/route.ts components/SocialProofPopup.tsx app/layout.tsx
   git commit -m "Add recently-purchased social proof popup"
   git push
