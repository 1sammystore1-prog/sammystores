NeuraPay: Add PalmPay Channel (BVN/NIN verification)
=====================================================
Updated: app/api/wallet/fund-neurapay/route.ts
Updated: app/fund/page.tsx

What changed:
- Previously the code only ever requested a Paga virtual account.
  There was no way to generate a PalmPay account, which is why no
  BVN/NIN menu ever appeared.
- Now the fund page has a Paga / PalmPay toggle. Selecting PalmPay
  shows a BVN/NIN dropdown + 11-digit number field (as PalmPay's
  API requires identity verification), matching NeuraPay's own docs:
    provider_channel: "Palmpay", identity_type: "BVN"|"NIN",
    license_number: "<11-digit BVN/NIN>"

HOW TO USE:
1. Upload this zip to your repo root in Codespace.
2. Run:
     unzip -o neurapay-palmpay.zip -d . && rm neurapay-palmpay.zip
3. Test locally: npm run dev
4. Commit:
     git add app/fund/page.tsx app/api/wallet/fund-neurapay/route.ts
     git commit -m "Add PalmPay channel with BVN/NIN verification to NeuraPay funding"
     git push
