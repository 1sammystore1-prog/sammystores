Fix: TypeScript build error in ticketReply.ts
================================================
Updated: lib/ticketReply.ts

The Vercel build failed with:
  Type 'string' is not assignable to type '"pending" | "open" | "closed"'.

Cause: the status parameter was typed as a plain `string`, but
Ticket.status only accepts one of those 3 exact values. The `.includes()`
check above it verifies this at runtime, but TypeScript doesn't
automatically narrow the type from that check alone - it needs an
explicit cast once we've confirmed it's valid.

Fix: `ticket.status = status as 'open' | 'pending' | 'closed';`
No behavior change - just satisfies the type checker.

HOW TO USE:
1. Upload to repo root in Codespace.
2. unzip -o fix-ticketreply-typeerror.zip -d .
   rm fix-ticketreply-typeerror.zip
3. git add lib/ticketReply.ts
   git commit -m "Fix TypeScript type error in ticketReply.ts"
   git push
4. Vercel will auto-redeploy - this time the build should pass.
