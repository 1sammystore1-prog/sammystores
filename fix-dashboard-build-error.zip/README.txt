Fix: build error in dashboard page (missing Active Numbers card)
====================================================================
Updated: app/dashboard/page.tsx

My earlier edit adding the Loyalty Tier card didn't account for a 5th
pre-existing card ("Active Numbers") sitting right after "Total
Transactions" in the same grid - it closed the grid's <div> one card
too early, leaving Active Numbers orphaned outside it, which broke the
JSX/build.

Fixed: reordered so all 5 cards (Wallet Balance, Refer Friends, Total
Transactions, Active Numbers, Loyalty Tier) sit inside one properly
closed grid, and changed the grid to 3 columns (wraps to a clean 3+2
layout) since 5 cards didn't divide evenly into 4.

HOW TO USE:
1. Upload to repo root in Codespace.
2. unzip -o fix-dashboard-build-error.zip -d .
   rm fix-dashboard-build-error.zip
3. git add app/dashboard/page.tsx
   git commit -m "Fix dashboard build error - restore Active Numbers card"
   git push
