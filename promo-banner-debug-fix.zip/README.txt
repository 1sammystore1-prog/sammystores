Promo banner debugging: simplified query + diagnostic logging
==================================================================
Updated: app/api/promo-banner/route.ts

FIRST - try this before assuming it's a code bug:
The dismiss (✕) button hides a banner PERMANENTLY in that browser via
localStorage - it doesn't reset daily like the referral banner does.
If you clicked dismiss while testing earlier, that alone explains it.
In browser DevTools console (F12 -> Console) on your site, run:
  localStorage.removeItem('dismissedPromoBanners')
then refresh. Or just test in an incognito window (fresh, no localStorage).

IF IT'S STILL NOT SHOWING after that:
Replaced the nested $and/$or Mongo query with a simpler flat query +
in-JS date filtering (functionally equivalent, easier to debug and
rules out any operator-combination subtlety). Also added a console.log
showing exactly how many active banners exist and whether each
qualifies within its date window - check Vercel's logs after visiting
the homepage once; the log line starts with "[promo-banner]".

HOW TO USE:
1. Upload to repo root in Codespace.
2. unzip -o promo-banner-debug-fix.zip -d .
   rm promo-banner-debug-fix.zip
3. git add app/api/promo-banner/route.ts
   git commit -m "Simplify promo banner query and add diagnostic logging"
   git push
4. After deploying, visit the homepage once, then check Vercel logs for
   the [promo-banner] line - send me what it says if the banner still
   doesn't show.
