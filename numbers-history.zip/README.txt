Numbers History - view/check/cancel past number purchases
==============================================================
New:     app/api/numbers/history/route.ts   (lists your past number purchases)
New:     components/NumbersHistory.tsx      (the history list UI)
Updated: app/numbers/page.tsx                (adds a "History" tab)

WHAT WAS MISSING BEFORE:
Buying a number only showed its status/SMS/cancel button for the current
browser session - leave the page or refresh, and that number was gone
forever from the UI (even though the purchase record existed in your
database the whole time). There was no way to come back later and check
for a code or cancel a number you'd just bought.

WHAT THIS ADDS:
A new "History" tab on the Virtual Numbers page listing every number
you've bought (both Server 1/TigerSMS and Server 2/BenOTP), each showing:
  - The phone number and service
  - Price and purchase time
  - "Check for Code" and "Cancel & Refund" buttons - using the exact
    same secure, ownership-checked endpoints that already existed
    (app/api/numbers/tiger/sms, tiger/cancel, benotp/status,
    benotp/cancel) - no new backend logic for the actual provider calls,
    just a way to reach them again later.

Numbers past ~20 minutes old are marked "Expired - too old to check or
cancel" instead of showing dead buttons - SMS activation numbers only
accept codes for a limited window (enforced by the provider itself, not
us), so a Check/Cancel button on a 3-day-old number would just always
fail. The phone number itself still always shows, regardless of age.

HOW TO USE:
1. Upload to repo root in Codespace.
2. unzip -o numbers-history.zip -d .
   rm numbers-history.zip
3. npm run dev - buy a test number, then click the "History" tab and
   confirm it shows up with working Check/Cancel buttons.
4. git add app/api/numbers/history/route.ts components/NumbersHistory.tsx app/numbers/page.tsx
   git commit -m "Add numbers purchase history with check/cancel actions"
   git push
