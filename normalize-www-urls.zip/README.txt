Normalize all URLs to www (avoid unnecessary redirect hops)
================================================================
Updated: components/ReferralBanner.tsx
Updated: app/referrals/page.tsx
Updated: app/robots.ts
Updated: app/sitemap.ts
Updated: lib/email.ts

Your domain redirects sammystorelogs.com -> www.sammystorelogs.com
(a 308 Permanent Redirect) - this is what broke the Telegram webhook,
since Telegram refuses to follow redirects for webhook delivery.

These 5 files were still using the non-www version. Browsers, email
clients, and search crawlers all follow redirects fine, so nothing here
was actually BROKEN - but every link took one unnecessary extra hop.
Now everything consistently points straight to the final www URL.

Also worth double-checking directly in NeuraPay's dashboard (not
something this code controls): confirm your webhook there is exactly
https://www.sammystorelogs.com/api/webhooks/neurapay - you mentioned
remembering it's the www version already, this is just belt-and-braces
since a wrong URL there could silently affect payment confirmations the
same way it broke Telegram.

HOW TO USE:
1. Upload to repo root in Codespace.
2. unzip -o normalize-www-urls.zip -d .
   rm normalize-www-urls.zip
3. git add components/ReferralBanner.tsx app/referrals/page.tsx app/robots.ts app/sitemap.ts lib/email.ts
   git commit -m "Normalize hardcoded URLs to www to avoid redirect hops"
   git push
