Admin dashboard card: NeuraPay fees absorbed
================================================
Updated: app/api/admin/stats/route.ts  (aggregates total fee cost)
Updated: app/admin/page.tsx            (new 4th stat card)

Adds a "NEURAPAY_FEES_ABSORBED" card to the admin dashboard showing:
  - Total ₦ absorbed this month (big number)
  - Deposit count this month + all-time total, in small text below

Sourced from the metadata.feeAbsorbedByStore field added to every
wallet_fund transaction in the last fix (lib/neurapayCredit.ts) -
aggregated in the database (not summed in JS) so it stays fast even
with thousands of transactions.

HOW TO USE:
1. Upload to repo root in Codespace.
2. unzip -o admin-fees-dashboard-card.zip -d .
   rm admin-fees-dashboard-card.zip
3. npm run dev - check /admin, confirm the 4th card appears (will show
   ₦0 until new deposits happen under the fee-tracking fix from before).
4. git add app/api/admin/stats/route.ts app/admin/page.tsx
   git commit -m "Add NeuraPay fees-absorbed card to admin dashboard"
   git push
