1) Image upload on support tickets + 2) Bot diagnostic logging
==================================================================

PART 1 - Image upload for support tickets
Updated: app/support/page.tsx - adds a "📎 Attach screenshot" button
  to BOTH the new-ticket form and the reply box, with image preview +
  remove button. 5MB client-side cap, images only.
Updated: app/api/support/tickets/[id]/route.ts - the REPLY endpoint now
  accepts and stores attachmentUrl (it was silently dropping it before -
  only ticket CREATION accepted it). Same server-side validation as
  creation (must be a real image data URI, re-checked size cap under
  5MB even if the client check is bypassed).

No other changes needed - models/Ticket.ts already had the
attachmentUrl field, and BOTH the customer support page and the admin
tickets page (app/admin/tickets/page.tsx) already render it as a
clickable image if present. This was half-built infrastructure that
just needed the actual upload button wired up.

Images are stored as base64 data URIs directly on the ticket document
(no external file storage needed) - same approach as the old manual
bank-transfer screenshot feature that was removed earlier.

PART 2 - Diagnostic logging for the support bot
Updated: lib/supportBot.ts - now logs EXACTLY why a message escalated:
  "[support-bot] ANTHROPIC_API_KEY is not set" (key missing), or
  "[support-bot] Anthropic API error (status X): <body>" (API call
  itself failed - wrong model access, bad key, quota, etc.)

You confirmed ANTHROPIC_API_KEY IS set on Vercel, so "always escalating"
is likely the second case - deploy this, send one more test message in
the chat widget, then check Vercel's function logs immediately. The
exact status code + response body will tell us precisely what's wrong
(e.g. 401 = key invalid/revoked, 404 = no access to that model, 429 =
rate limited or out of credits, 400 = malformed request).

HOW TO USE:
1. Upload to repo root in Codespace.
2. unzip -o ticket-images-and-bot-diagnostics.zip -d .
   rm ticket-images-and-bot-diagnostics.zip
3. npm run dev - test: open a ticket, attach a screenshot, send it -
   confirm it shows as a clickable thumbnail. Also test replying to an
   existing ticket with an image.
4. git add app/support/page.tsx "app/api/support/tickets/[id]/route.ts" lib/supportBot.ts
   git commit -m "Add image upload to support tickets; add bot diagnostic logging"
   git push
5. After deploying, test the chat widget once and check Vercel logs for
   the [support-bot] line - send me what it says.
